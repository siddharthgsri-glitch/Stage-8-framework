# Handoff: Stage 8 framework: Cambridge Lower Secondary learning app

## Overview
A gamified, interactive learning web app for **Cambridge Lower Secondary Stage 8** students (age 12–13). It covers **Maths (25 chapters), Science (12 chapters, 4 strands, plus 4 end-of-stage reviews and 2 extra fluids chapters), Computing (6 units), English (8 chapters) and French (8 chapters)**. Topics follow the student-book contents list in `ref/contents.txt` (Maths, Science, Computing). The English and French chapters were designed in this project.

Every topic runs the same loop: **Learn cards → interactive Models (figures, simulations, labelled diagrams) → Quiz (up to 3★)**. Every chapter then has **Practice (3★) → Boss battle (bronze/silver/gold medal) → Treasure (recap, formula sheet, collectable card)**.

Around that core sit:
- a game layer: XP, levels, coins, streaks, combos, daily quests, badges, a shop and chests
- multi-player profiles on one device, with a 4-digit PIN
- an AI study buddy, a speaking coach and a formula book
- a **Study zone**: daily spaced-repetition mix, mistake notebook, timed mock exams, revision planner, card album, printable progress report, weekly class challenge, teacher mode with homework, accessibility settings, offline support, and five subject labs (maths step checker, science virtual practicals, AI writing feedback, AI French conversation, in-browser Python)

## About the Design Files
The files in this bundle are **design references created in HTML/React (in-browser Babel)**. They are working prototypes that show the intended look, content and behaviour; they are **not production code to ship as-is**. Recreate the app in a proper environment: if there is an existing codebase, use its patterns; otherwise **React + TypeScript + Vite (or Next.js)** is the natural fit, since the prototype is already React-component based. The prototype loads ~45 Babel scripts at runtime and shares state through `window` globals and `localStorage`; a real build should use modules, a bundler, a router and a backend.

Most of the content files (`book-*.jsx`, `curriculum8.js`, `formulas.jsx`) are **pure data** and can be converted almost directly to JSON/TS modules. The model components (`w-*.jsx`) are self-contained React components that can be ported one by one.

## Fidelity
**High-fidelity.** Colours, type, radii, shadows, copy, interactions, scoring rules and content are final. Recreate the UI pixel-faithfully. Text content (questions, explanations, Learn cards, formulas) should be carried over verbatim. Curriculum codes (e.g. `8Ni.01`) follow the Cambridge format but **must be checked against the official Cambridge framework** before release.

### What must change in production
1. **Accounts and progress must move to a real backend.** In the prototype, profiles and progress live only in the browser's `localStorage` (see `auth-boot.js`). Needed: a hosted database plus authentication (student PIN login under a class/school code, teacher accounts), cross-device sync, and teachers seeing their whole class from anywhere.
2. **AI calls** (`window.genspark.complete(prompt)` in `companion.jsx`, `topic8.jsx`, `study-labs.jsx`) must go through a server endpoint backed by an LLM, with rate limiting and child-safe system prompts.
3. **Python runner** uses Skulpt from a CDN (`study-labs.jsx`, `loadSkulpt()`). Keep Skulpt (bundled) or switch to Pyodide in a Web Worker.
4. **Speech** uses the Web Speech API (`speechSynthesis` for read-aloud and French audio, `SpeechRecognition` for speaking practice). Keep it, with a fallback message on unsupported browsers.

---

## App structure & routing
The prototype uses a string route kept in `localStorage['s8f-route']`. Suggested real routes:

| Prototype route | Real route | Screen |
|---|---|---|
| (signed out) | `/login` | AuthScreen: Welcome → Who's playing? → PIN pad; Create player (3 steps) |
| `home` | `/` | Home |
| `subject:<id>` | `/subject/:id` | Subject world (maths, science, computing, english, french) |
| `book:<chapterId>` | `/chapter/:id` | Chapter player (map → topic → Learn/Models/Quiz; practice; boss; treasure) |
| `topic:<topicId>` | `/practice/:topicId` | AI practice by curriculum objective |
| `formulas` | `/formulas` | Formula book (5 subject tabs) |
| `speak[:lang[:set]]` | `/speak` | Speaking coach |
| `shop`, `trophies`, `profile`, `leaderboard` | same | Game screens |
| `study` | `/study` | Study zone hub |
| `mix` | `/study/daily` | Today's 10 minutes |
| `mistakes` | `/study/mistakes` | Mistake notebook |
| `exam` | `/study/exam` | Mock exams |
| `planner` | `/study/planner` | Revision planner |
| `album` | `/study/cards` | Card album |
| `report` | `/study/report` | Printable progress report |
| `class` | `/study/class` | Weekly class challenge |
| `teacher` | `/teacher` | Teacher mode (PIN) |
| `settings` | `/settings` | Reading & display + offline + accounts info |
| `lab:steps / practical / writing / convo / python` | `/lab/:id` | Subject labs |

Top bar (all pages except the chapter player): logo, subject tabs, 🎤 Speak, 🧮 Formulas, 🎒 Study, and the HUD (avatar + name + level + XP bar, 🔥 streak, 🪙 coins, ⚡ combo, 🛍️ shop, 🏆 trophies, 🚪 sign out, 💬 Ask). A floating "Stuck? Ask" pill sits bottom-right and an "Aa" accessibility button bottom-left.

---

## Screens / Views

### 1. Auth (`auth.jsx`)
- **Welcome**: a bright gradient background with floating emoji (⭐ 🚀 🧪 📐 🏆) and one large white card, with "I've played before" and "New player" buttons.
- **Who's playing?**: a grid of large player cards (avatar, name, class, level). A search box appears when there are more than 6 players.
- **PIN pad**: 4 dots and a 3×4 keypad with big keys. It submits automatically on the 4th digit and also accepts the keyboard. A wrong code makes the dots shake and shows "Wrong code, try again!". After 5 wrong tries the profile locks for 30 s.
- **Create player** (progress bar at the top, back arrow on each step):
  1. Name, plus a class chip (7A…8D) or free text (optional).
  2. Pick an avatar (8 starters: fox, owl, panda, tiger, octopus, penguin, unicorn, robot).
  3. Choose a 4-digit code and confirm it.
  The username is generated automatically: `name-class`, with a number added if it's taken.

### 2. Home
- A hero row with two columns:
  - **Left (welcome card):** avatar, "Hi {name}!", level and title, the H1 "Ready for today's adventure?", an XP bar, and buttons **▶ Continue: {chapter}** plus **⏱️ Today's 10 minutes** (or "✓ Today's mix done"). Chips below: "📒 N mistakes to fix", "🗓️ N days to your exam", "📝 Mock exam".
  - **Right:** the **Daily quests** card (3 quests with progress bars and Claim buttons, plus a 🎡 Daily spin).
- **Homework card** (only when a teacher has set homework): yellow 3 px border, due date, the teacher's message, and one row per chapter showing topics done (e.g. "2/4") with ✓ when complete.
- **Choose a world**: 5 large subject tiles, each with an icon, name, blurb, star progress bar and "⭐ x/y".
- A two-column row: **Class leaderboard** (compact) | **Team goal** (compact class challenge).
- **Power tools** cards: Study buddy, Speaking coach, Formula book, Study zone, Prize shop, Trophy room.

### 3. Subject world
- A coloured banner (subject accent gradient) with the icon, "{Subject} world", "N chapters to conquer…", and a star bar.
- Chapter cards in a 4-column grid. Each card shows the number badge, title, "N topics · N models · 🧮 N formulas", a progress bar and "⭐ x/y".
- Science is grouped by strand header: Biology (green), Chemistry (blue), Physics (orange), Earth & space (purple).
- Below: **🤖 Extra AI practice by objective**, cards per curriculum strand/topic from `curriculum8.js`.

### 4. Chapter player (`player8.jsx`)
- **Map view**: chapter title and "N topics · N models & diagrams · 1 boss". Each topic is a card with three big tiles: **Learn** (yellow, "6 explanation cards"), **Models** (blue, "N to explore") and **Quiz** (pink, "win up to 3 ⭐"). Below the tiles are an inline formula strip and chips for each model. At the bottom: the **Formula sheet** card, then three large tiles: **Practice** (purple), **Boss battle** (red) and **Treasure** (gold).
- **Topic view**: a sticky header (back button, "SUBJECT · CHAPTER n · STRAND", topic title, star counter) and a segmented control: 📖 Learn / 🧮 Formulas / 🎮 Play / ⚡ Quiz.
  - **Learn**: a deck of cards (swipe or arrows) with a 🔊 Listen button.
  - **Play**: a two-column layout. The left card holds a model tab bar ("MODEL 1 · name", "MODEL 2 · name"…) with the active interactive below it. The right card is **Missions**: a numbered task list that auto-ticks from the model's reported state, "FORMULA TO USE" boxes, and a "N of M missions" button that unlocks "See what you found →", plus Skip.
  - **Quiz**: progress dots, a combo bar, an optional "Show formulas" toggle, then one question at a time.
- **Practice**: 5–6 questions; stars are awarded by score (100% = 3★, ≥66% = 2★, ≥40% = 1★).
- **Boss**: an intro screen (boss emoji floating, HP, 3 ❤️), then an arena (avatar + hearts vs boss + HP bar). Each right answer hits the boss; each wrong answer loses a heart. Medal by hearts left: 3 = 🥇, 2 = 🥈, 1 = 🥉. Hints are disabled.
- **Treasure**: open the chest (modal with a random prize), then the **collectable card reveal** (flip-in animation), Power-up recap cards, the formula sheet, a word bank, and Print / Back to map / Next chapter.

### 5. Question component (`GQ` in `player8.jsx`)
- Question types: `mc` (A–D option buttons in 4 colours), `input` (free text, normalised compare: lowercase, spaces removed, trailing % and ° ignored) and `order` (list with ↑/↓ buttons).
- Buttons: **Check**; **💡 Hint 1: a nudge** → **🧭 Hint 2: the method (−½★)** → **📖 Hint 3: full solution (−1★)**; **✂️ 50:50** (uses a power-up); **💬 Hint from buddy** (opens the AI companion with a seed prompt).
  - Hint 1: for MC, names one wrong option; for input, gives the answer's length and first character; for order, gives the first item.
  - Hint 2: the topic's formula, or the first sentence of the explanation.
  - Hint 3: the full explanation plus the answer.
- Feedback: green "Awesome!/Nailed it!/Correct!/Brilliant!" or red "Not quite…", plus the `why` text.
- Every answer is recorded in the spaced-repetition store (see State).

### 6. Formula book
Tabs for Maths, Science, Computing, English and French. There is one card per chapter, and each formula card shows its name, equation/rule and an example. Maths and Science formulas include a **calculator**: pick the unknown, type the other values, see the result. English and French entries are **writing frames / grammar rules** (e.g. "The writer uses [technique], '[quotation]', to [effect]", "opinion + subject + parce que c'est + (très) + adjective").

### 7. Study zone (`study-pages.jsx`, `study-labs.jsx`)
- **Hub**: a 14-card grid (auto-fill, min 220 px).
- **Today's 10 minutes**: a banner with stats (from mistakes / due / mixes done) and a Start button. Below it, a "How it works" card showing the 7 Leitner boxes (Today, 1, 2, 4, 8, 16, 32 days). The question runner shows the source chapter and a "📒 from your notebook" tag. The results page links to the notebook.
- **Mistake notebook**: a coral gradient banner (to fix / cleared, "Retry N mistakes"), subject filter chips, then cards showing source, "✗ wrong N×" or "✓ 1/2 right", the question, an expandable answer and explanation, and Retry / Open chapter buttons.
- **Mock exams**:
  - **Setup**: subject chips; length: Short (10 Qs, 15 min), Standard (20 Qs, 30 min), Full (30 Qs, 45 min). Each question gets 90 s.
  - **During**: a sticky dark timer pill (turns red and pulses under 60 s) with a "Hand in" button. Hints are off.
  - **Results**: a conic score ring, a grade (≥80% "Excellent", ≥60% "Good", ≥40% "Getting there", else "Keep practising"), Strong (≥75%) and Needs-work (<50%, clickable) lists, bars by chapter (green ≥75%, amber ≥50%, red), and the past papers list.
  - **Marks**: MC = 1, other types = 2. Questions come from the chapter `challenge` and `practice` arrays.
- **Revision planner**:
  - **Form**: exam date, subjects, minutes per day (20/30/45/60), rest-day chips.
  - **Plan**: chapters sorted weakest first, scored by `0.6 × star% + 0.4 × worst mock % − 0.05 × mistakes`. Each day gets the daily mix plus ⌊minutes/20⌋ chapters; every 3rd day adds "Fix 5 mistakes", every 7th a short mock, and the last 2 days are mock exams.
  - **Display**: a grid of day cards with checkboxes (+5 XP each); today is outlined; there is a print stylesheet.
- **Card album**: subject chips with counts, then a grid of cards (locked = greyscale 🔒 "Finish: {chapter}"). Card types: common, shiny (every 5th chapter, gold gradient) and rare (review chapters, purple/blue gradient). Clicking a card opens a modal with its fact.
- **Progress report** (print-ready white paper): name, class and date; KPIs (level, best streak, time learning, correct answers); a subject table (topics done, progress bar, best mock, time); Strengths (chapters ≥75%) and To work on (chapters started but <40%); mistakes count; a 7-day time bar chart; teacher comment and parent signature lines.
- **Weekly class challenge**: goal = max(60, 40 × players) ⭐ per week (Mon–Sun). Contributions = stars earned since the week began. It shows a gradient progress bar and contributor chips, and once the goal is hit, each player can claim once (+80 XP, +100 coins, chest).
- **Teacher mode**: create, then enter a 6-digit PIN (hashed; unlocked per browser session).
  - **Class overview**: a table showing avatar, name, class, level, ⭐, topics, homework done (x/y pill), mistakes, last active, and a 📄 Report button.
  - **Set homework**: due date, message, subject chips and a chapter checklist.
- **Settings**:
  - Font: Default / Lexend / Atkinson Hyperlegible.
  - Text size: 0.9 / 1 / 1.12 / 1.25 (zoom).
  - Toggles: tap-to-read-aloud (the tapped text is outlined yellow while spoken; French is auto-detected), high contrast, reduce motion.
  - Offline status, and an explanation of online accounts.
- **Labs**:
  - **Maths step-by-step**: pick an equation or type your own. The student types each line; each line is parsed as linear (both sides reduced to `mx + c` by sampling) and its solution compared with the original. Feedback per line: "✓ Still balanced", "✗ This line gives x = …", "✅ Solved!" (when the line is `x = n`), or "⚠️ can't read".
  - **Science virtual practicals** (3 investigations: dissolving vs temperature, ramp height vs speed, marble chip size vs reaction time). Five steps:
    1. Plan: sort 7 variables into independent / dependent / control / not needed.
    2. Predict.
    3. Measure: 3 repeats per value; one result is a planted anomaly at +45%.
    4. Graph: an SVG with all repeats and a mean line; tap the anomaly.
    5. Conclude: choose the conclusion, then see the explanation and evaluation.
  - **AI writing feedback**: 4 task prompts and a textarea with live counters (words, connectives, techniques, average sentence length, missing capitals). The AI returns JSON: scores 0–5 for structure, language, accuracy and purpose; www[]; ebi[]; spelling[]; techniques[]; rewrite; overall. If the AI is unavailable, a heuristic fallback scores the text. Score history is kept, with a toast when a score improves.
  - **AI French conversation**: 4 scenarios (café, pen-pal Lucas, clothes shop, directions). Chat bubbles; replies are spoken in fr-FR; an English translation toggle; a correction under the student's bubble ("✏️ Better: … · tip"); idea chips; a 🎤 speak button (fr-FR speech recognition); accent buttons.
  - **Python**: 6 example programs (hello, guessing game, recycling quiz, times table, binary converter, validation) and an editor with line numbers (Tab inserts 4 spaces; code is autosaved). The output terminal shows user input in amber, prompts in blue and errors in red with a tip; `input()` opens an inline field. 4 challenges are detected by code patterns.

### 8. Interactive models (`w-*.jsx`, ~280 components)
All models share one contract: `function Model({ cfg, onState })`. `cfg` is static config from the chapter data, and `onState(obj)` reports state, which the Missions panel tests with predicates (e.g. `s => s.found >= 5`). `useRep(onState, state, deps)` is the helper that reports. Shared primitives are in `w-core.jsx`: `WCtl`, `WSeg` (segmented control), `WSl` (slider), `WRead` (readout grid), `wxShuffle`, `wxFmt`. `LDIAG` + `W.labeldiag` in `w-labeldiag.jsx` handle explore-then-label diagrams (heart, lungs, skeleton, cells, eye, ear, plant, newspaper, formal letter…). The full list of models per topic is in the `secs[].w` and `secs[].extra` fields of each `book-*.jsx` file.

---

## Interactions & Behaviour
- **Buttons**: a 3D "pressable" style with a 4 px bottom shadow, translateY(−2px) on hover and translateY(3px) on active, with 80 ms transitions.
- **Animations**: `gbounce` (0.9 s cubic-bezier(.3,1.6,.5,1), scale 0.2→1.15→1), `gfloat` (2.4 s, translateY −10px, rotate −4°), `gpulse`, a shake on wrong answers, and confetti on big wins. All are disabled by "reduce motion".
- **Rewards** (`game.jsx`):
  - Correct answer: +10 XP + combo bonus (min(combo−1, 5) × 2) and +2 coins.
  - Topic quiz: stars = 3 (0 misses) / 2 (≤1 miss; hint 2 counts ½ a miss, hint 3 counts 1) / 1. Reward: +10 XP and +5 coins per star.
  - Level curve: level n needs 100 + (n−1) × 40 XP. Each level-up gives +50 coins and a modal.
  - Titles: Rookie (1), Explorer (3), Thinker (5), Scholar (8), Genius (12), Mastermind (16), Legend (20).
  - Streak: counted per calendar day; a "streak freeze" power-up saves a missed day.
  - Badges: 25 in total, each worth +25 coins.
  - Daily quests: 3 random quests from a pool of 11; finishing all 3 gives a chest.
- **Spaced repetition** (`study-core.jsx`, `SR`):
  - Each question has a key `chapterId|c|secIndex|qIndex` (topic check), `|p|i` (practice) or `|x|i` (challenge).
  - A clean correct answer (fewer than 2 hints used) moves it up one box (0→6); the next review is due after [0, 1, 2, 4, 8, 16, 32] days.
  - A wrong answer sets box = 0, marks it as a mistake and makes it due now.
  - A mistake clears after 2 consecutive clean correct answers (+15 XP, +5 coins).
  - The daily mix is ≤4 mistakes + ≤4 due questions, filled from the weakest started chapters.
- **Time tracking**: +15 s every 15 s while the tab is visible, recorded per subject (from the current route) and per day.
- **Validation**:
  - Create player: name required; PIN must be exactly 4 digits and typed twice.
  - Teacher PIN: exactly 6 digits.
  - Writing lab: at least 30 words before submitting.
  - Planner: at least 1 subject.
- **Responsive**:
  - Grids reduce to 2 columns, then 1, under 860 px and 700 px.
  - The chapter player's Play view stacks the model above Missions on narrow screens.
  - Tap targets are ≥44 px.

## State Management
Per-user keys (prefix `s8f-`; in production these become per-user tables):

| Key | Content |
|---|---|
| `s8f-game` | xp, coins, combo, streak {count,best,last}, daily {date,quests[],spun}, badges{}, owned[], avatar, theme, frame, power{hint,shield,freeze,heart}, stats{correct,answers,bestCombo,figures,sections,bosses,golds,stars,chests,asked,spoken,learn} |
| `s8f-progress` | book{chapterId: {secDone{n: stars}, stars, medal, chest}}, practised{topicId: n} |
| `s8f-pos2-<chapterId>` | last view within a chapter (resume) |
| `s8f-sr` | {questionKey: {b, w, r, s, m, due, last, fixed}} |
| `s8f-mix` | {date, count, best} |
| `s8f-exams` | [{subj, date, got, tot, pct, by{chapterId:{t,got,tot}}, time}] (last 30) |
| `s8f-plan` | {exam, subs[], mins, days[{d, items[{t, r, done}]}]} |
| `s8f-time` | {total, by{subject}, days{date}} seconds |
| `s8f-writing` | writing score history |
| `s8f-py`, `s8f-pych` | saved Python code, challenges done |
| `s8f-a11y` | {font, size, read, motion, contrast} |

Device/class-wide keys (they become class/school tables in production):
- `S8DB`: users {username: {name, cls, salt, hash, created, last, data}}
- `S8CLASS`: weekly challenge {week, base{user: stars}, claimed[], goal}
- `S8HW`: homework {items[chapterIds], note, due}
- `S8TEACHER`: hashed teacher PIN

**Suggested backend schema**: `schools`, `classes`, `users(role: student|teacher)`, `progress(user, chapter, topic, stars, medal)`, `answers(user, questionKey, correct, hints, ts)` (from which the SR state is derived), `exams`, `plans`, `homework(class, chapters, due, note)`, `class_challenges`, `time_logs`. The teacher dashboard and progress report become server queries.

**Content model** (convert `book-*.jsx` into JSON/TS):
```ts
type Q = { type:'mc'|'input'|'order'; q:string; opts?:string[]; a?:number; accept?:string[]; items?:string[]; order?:number[]; why:string; h1?:string; h2?:string; marks?:number };
type Section = { n:string; t:string; w:string /*model id*/; cfg?:any; intro:string; tasks:[string, (state, has)=>boolean][]; extra?:[w:string, cfg:any, label:string][]; notice:ReactNode[]; check:Q[] };
type Chapter = { id:string; subj:'maths'|'science'|'computing'|'english'|'french'; n:number|string; title:string; strand:string; codes:string[]; secs:Section[]; practice:Q[]; challenge:Q[]; recap:{points:string[]; terms:[string,string][]}; review?:boolean };
```
Mission predicates are functions in the prototype. In production, express them declaratively (e.g. `{key:'found', op:'>=', value:5}`) so the content can live in a CMS or JSON.

## Design Tokens
**Fonts** (Google Fonts):
- **Fredoka** 400/500/600/700: headings, buttons, numbers.
- **Nunito** 400/600/700/800: body text.
- Accessibility options: **Lexend** and **Atkinson Hyperlegible**.
- Code: `ui-monospace, Menlo`.

**Theme** (switchable in the shop; `--t1` / `--t2` / `--t3`):

| Theme | --t1 | --t2 | --t3 |
|---|---|---|---|
| Sunny (default) | #ffb347 | #ff6f91 | #fff7e6 |
| Ocean | #4facfe | #00c9a7 | #eefaff |
| Jungle | #43c463 | #c3e44a | #f2fbe9 |
| Candy | #ff7eb3 | #a78bfa | #fff0f7 |
| Galaxy | #7f5af0 | #2cb1ff | #f1eeff |

**Ink & surfaces**:
- Ink: `--g-ink` #2b2140; secondary ink: `--g-ink2` #5b5170; tertiary: #8b84a0.
- Rules/borders: #ece6f5; soft panel: #f6f1fd / #faf8fd; card: #ffffff.
- Page background: `--t3` with two radial glows (t1 at 10% 0%, t2 at 90% 10%, ~22–25% mix).

**Subject accents** (`--acc` / `--acc-t` tint):

| Subject / strand | Accent | Tint |
|---|---|---|
| Maths | oklch(0.62 0.17 255) | oklch(0.94 0.04 255) |
| Science | oklch(0.64 0.17 150) | oklch(0.94 0.05 150) |
| English | oklch(0.65 0.18 30) | oklch(0.94 0.04 30) |
| French | oklch(0.6 0.17 300) | oklch(0.94 0.04 300) |
| Computing | oklch(0.62 0.14 200) | oklch(0.94 0.04 200) |
| Biology | oklch(0.64 0.17 150) | |
| Chemistry | oklch(0.6 0.16 235) | |
| Physics | oklch(0.68 0.17 55) | |
| Earth & space | oklch(0.58 0.17 285) | |

**Status colours**:
- Correct: #43c463 (text #23803c / #1f7a39; background #dcf8e5 / #eafbef).
- Wrong: #ff6b6b / #e04848 (background #ffeded / #ffe3e3).
- Gold / amber: #ffc75f.
- Highlights: yellow #fff0a8, blue #dcecff, pink #ffd9e6, peach #ffedc2.

**Radius**: cards 22 px (`--g-rad`); buttons 16 px; chips and pills 999 px; tiles 14–20 px; inputs 12–14 px.

**Shadow**: `--g-sh: 0 6px 0 rgba(43,33,64,.12), 0 18px 40px -20px rgba(43,33,64,.35)`. Pressable elements use `0 4–5px 0 <darker tone>`.

**Type scale**:
- H1: clamp(32px, 4.4vw, 50px), line-height 1.05.
- H2: 28 px. H3: 22 px.
- Body: 15–17 px. Small: 12–13 px. Tags: 12 px uppercase, +0.05em tracking, weight 800.
- Model text: 19–30 px Fredoka.

**Spacing**: 4 / 6 / 8 / 10 / 12 / 14 / 16 / 18 / 20 / 22 / 28 / 32 px. Section headings have a 32 px top margin, and pages end with 60 px of bottom space.

## Assets
- **No raster images.** All imagery is emoji (avatars, subject icons, cards, bosses) or inline SVG drawn in the model components (diagrams, graphs, circuits, maps).
- If a custom illustration set is commissioned, keep emoji as the fallback.
- Fonts come from Google Fonts. The Python runtime is Skulpt 1.2.0 from jsDelivr. React 18.3.1 and Babel standalone are loaded from unpkg (prototype only).

## Files
- `Stage 8 framework.html`: entry point. Contains script order, subject config, Home, SubjectPage, routing (`App`) and service-worker registration.
- `auth-boot.js`, `auth.jsx`: multi-player profiles, PIN login, profile page, leaderboard.
- `game.jsx`: XP, levels, coins, streaks, quests, badges, shop, chests, spin, HUD, modals, confetti.
- `player8.jsx`: question component, chapter map, topic player (Learn / Play / Quiz), practice, boss, treasure.
- `formulas.jsx`: all formulas and writing/grammar frames, calculators, formula book.
- `study-core.jsx`: spaced repetition, mistakes, daily-mix builder, time tracking, accessibility, class challenge, homework, teacher PIN, collectable card data, extra badges and quests.
- `study-pages.jsx`: study hub, daily mix, mistakes, mock exams, planner, album, report, class challenge, homework card, teacher mode, settings.
- `study-labs.jsx`: maths step checker, science practicals, writing feedback, French conversation, Python runner.
- `book-maths-a/b/c.jsx`, `book-science.jsx`, `book-extra.jsx` (end-of-stage reviews), `book-fluids.jsx`, `book-computing.jsx`, `book-english.jsx`, `book-french.jsx`: **all chapter content** (topics, Learn notes, missions, model configs, questions, recaps).
- `curriculum8.js`: Stage 8 curriculum objectives, used by AI practice.
- `w-core.jsx` and the other `w-*.jsx` files: interactive models and diagrams. `interactives*.jsx`, `chapters8.jsx` and `player.jsx` are earlier shared helpers that are still loaded.
- `companion.jsx` (AI study buddy), `speaking.jsx` (speaking coach), `topic8.jsx` (AI practice page).
- `margin.css`, `margin8.css` (base), `widgets.css` (models), `game.css` (game UI), `study.css` (study zone, accessibility, labs).
- `sw.js`, `manifest.json`: offline support and install-as-app.
- `ref/contents.txt` (student-book contents list), `ref/stage8.txt` (curriculum framework extract).

To run the prototype, serve the folder over HTTP (e.g. `npx serve`) and open `Stage 8 framework.html`.
